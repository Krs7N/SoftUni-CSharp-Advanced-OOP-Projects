﻿namespace _03.Raiding.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
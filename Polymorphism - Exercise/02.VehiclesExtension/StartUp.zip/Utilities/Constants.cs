﻿namespace _02.VehiclesExtension.Utilities
{
    public class Constants
    {
        public const double CarAirConditionerFuelConsumption = 0.9;
        public const double TruckAirConditionerFuelConsumption = 1.6;
        public const double BusAirConditionerFuelConsumption = 1.4;
    }
}
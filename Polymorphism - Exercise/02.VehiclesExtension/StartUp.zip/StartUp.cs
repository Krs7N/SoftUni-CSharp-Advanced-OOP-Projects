﻿namespace _02.VehiclesExtension
{
    using System;

    using Models;
    using Models.Contracts;

    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carProperties = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] truckProperties = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] busProperties = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            Vehicle car = new Car(double.Parse(carProperties[1]), double.Parse(carProperties[2]), double.Parse(carProperties[3]));
            Vehicle truck = new Truck(double.Parse(truckProperties[1]), double.Parse(truckProperties[2]), double.Parse(truckProperties[3]));
            Bus bus = new Bus(double.Parse(busProperties[1]), double.Parse(busProperties[2]),
                double.Parse(busProperties[3]));

            int numberOfCommands = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfCommands; i++)
            {
                string[] commands = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                switch (commands[0])
                {
                    case "Drive":
                        if (commands[1] == "Car")
                        {
                            car.Drive(double.Parse(commands[2]));
                        }
                        else if (commands[1] == "Truck")
                        {
                            truck.Drive(double.Parse(commands[2]));
                        }
                        else
                        {
                            bus.Drive(double.Parse(commands[2]));
                        }
                        break;
                    case "Refuel":
                        if (commands[1] == "Car")
                        {
                            car.Refuel(double.Parse(commands[2]));
                        }
                        else if (commands[1] == "Truck")
                        {
                            truck.Refuel(double.Parse(commands[2]));
                        }
                        else
                        {
                            bus.Refuel(double.Parse(commands[2]));
                        }
                        break;
                    case "DriveEmpty":
                        bus.DriveEmpty(double.Parse(commands[2]));
                        break;
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
            Console.WriteLine($"Bus: {bus.FuelQuantity:f2}");
        }
    }
}

﻿namespace _01.Vehicles.Utilities
{
    public class Constants
    {
        public const double CarAirConditionerFuelConsumption = 0.9;
        public const double TruckAirConditionerFuelConsumption = 1.6;
    }
}